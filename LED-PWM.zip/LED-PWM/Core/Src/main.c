/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  * - STM32CubeMX로 생성된 초기 템플릿으로, 사용자 코드는 USER CODE BEGIN/END 사이에 추가해야 합니다.
  * - 코드 구조는 STM32 HAL 라이브러리 사용을 전제로 구성됩니다.
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "tim.h"
#include "gpio.h"
/* USER CODE BEGIN Includes */
// 여기에 추가적인 라이브러리나 헤더 파일을 포함할 수 있습니다.
/* USER CODE END Includes */

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
// 사용자가 정의한 데이터 타입이나 구조체를 포함할 수 있는 섹션입니다.
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
// 필요한 매크로 정의를 추가할 수 있는 섹션입니다.
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */
// 필요한 매크로 함수를 정의할 수 있는 섹션입니다.
/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN PV */
// 사용자 정의 변수를 선언하는 섹션입니다.
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */
// 사용자 정의 함수의 프로토타입을 선언하는 섹션입니다.
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
// 초기화 외 추가적인 사용자 코드나 함수가 포함될 수 있습니다.
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */
  // 사용자 코드 초기화 단계: 필요한 변수 선언 및 초기값 설정.
  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/
  // HAL 라이브러리 초기화 및 MCU 설정 섹션.

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();
  // HAL 라이브러리 초기화: MCU 주변장치 초기화, SysTick 타이머 설정 등.

  /* USER CODE BEGIN Init */
  // 추가적인 초기화가 필요하면 이곳에 추가합니다.
  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();
  // 시스템 클럭 설정: MCU 클럭 및 PLL 설정.

  /* USER CODE BEGIN SysInit */
  // 추가적인 시스템 초기화가 필요하면 이곳에 추가합니다.
  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  // GPIO 초기화: CubeMX에서 설정한 핀 모드 및 상태 초기화.
  MX_TIM3_Init();
  // TIM3 타이머 초기화: PWM 출력에 필요한 타이머 설정.

  /* USER CODE BEGIN 2 */
  // TIM3 타이머의 PWM 모드 시작.
  HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_3);
  /* USER CODE END 2 */

  /* Infinite loop */
  // 프로그램의 메인 루프: 여기서 지속적으로 동작하는 코드 작성.

  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
    // LED 밝기 증가 루프.
    for (int i = 1; i < 255; i++)
    {
      __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_3, i);
      // PWM 듀티 사이클 설정: 타이머 비교 값을 증가시켜 밝기 증가.
      HAL_Delay(10);
      // 딜레이를 통해 변화 속도를 제어.
    }

    // LED 밝기 감소 루프.
    for (int i = 255; i > 0; i--)
    {
      __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_3, i);
      // PWM 듀티 사이클 설정: 타이머 비교 값을 감소시켜 밝기 감소.
      HAL_Delay(10);
      // 딜레이를 통해 변화 속도를 제어.
    }
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 25;
  RCC_OscInitStruct.PLL.PLLN = 192;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_3) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
